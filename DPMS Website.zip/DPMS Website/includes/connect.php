<?php

$con=mysqli_connect('localhost:3308','root','','mydairy');

if(!$con){
    echo "connection successfull";
}

    





?>