<div class = "bg-info p-3 text-center">
    <p>All rights reserved © Designed by RMCET Student-2024 </p>

    </div>
