<?php
//sessiond()
session_start();
$_SESSION['username']= "Purva";
$_SESSION['password']= "coding";
$_SESSION['email']= "coding@gmail.com";
echo "Session data is saved";


?>
