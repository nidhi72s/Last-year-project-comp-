<?php

$con=mysqli_connect('localhost:3308','root','','mydairy');

if(!$con){
    die(mysqli_error($con));
}

    





?>